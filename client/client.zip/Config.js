var config = {

    localMode: true,

    localDomain: "data/",
    SAPDomain: "",

    getMovies: {
        url: "getMovies"
    },

    getSubtitle: {
        url: "getSubtitle"
    },

    copyMovie: {
        url: "copyMovie"
    },

    webServerIP: "192.168.1.22",
    webServerPort: "8080"

};
